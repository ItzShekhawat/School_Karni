<?php
$user_DB = "root";
$password_DB = '';
$nameDB = '------';
$db = mysqli_connect("localhost", $user_DB, $password_DB, $nameDB) or die("Connection failed");

    if(isset($_POST['submit'])){
        $username = $_POST['name'];
        $pws = $_POST['psw'];

        $query = "SELECT * FROM `users` WHERE username = '$username' AND password = '$pws'";
        // Execute the query
        $result = mysqli_query($db, $query) or die("Server query not working");

        if ($result->num_rows == 1){
            echo("OK");
        }else{
            echo("Errore");
        }
    }

?>